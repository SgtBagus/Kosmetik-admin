define({
  "name": "Documentation Rest Api (SOP Smartsoft)",
  "version": "1.0.0",
  "description": "Documentation all rest api and how to access Rest Api in SOP Smartsoft",
  "apidoc": "0.3.0",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-02-13T09:11:37.994Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
